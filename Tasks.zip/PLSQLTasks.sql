
SET ECHO ON
/*
*
*
* Enter full path and file name for log file, e.g. c:\logs\log.txt
* below
*
*/

SPOOL &path_and_file_name

/*1*/
/*Creating Table Documents*/

CREATE TABLE Documents 
    (
     Document_Id                           NUMBER   CONSTRAINT Documents_PK PRIMARY KEY
    ,Document_Name          VARCHAR2(50)   NOT NULL
/* For VARCHAR2 in SQL max value is 4000 bytes but in PL/SQL max value is 32767 bytes */
    ,Document_Description   VARCHAR2(4000)
    ,Record_Timestamp       TIMESTAMP      NOT NULL
    ,Timestamp              TIMESTAMP      NOT NULL
    ,Record_User_Id         VARCHAR2(50)   NOT NULL
    ,User_Id                VARCHAR(50)    NOT NULL
    );

/*2*/
/* Creating sequence for table 'Documents' */

CREATE SEQUENCE Documents_Id_SEQ;

/*3*/
/* Inserting data in table 'Documents' using SEQUENCE                */
        
        INSERT INTO Documents VALUES (Documents_Id_SEQ.nextval, 'PASSPORT'          , 'XXX 00001', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 11, 11 );
        INSERT INTO Documents VALUES (Documents_Id_SEQ.nextval, 'PASSPORT'          , 'XXX 00002', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 11, 11 );
        INSERT INTO Documents VALUES (Documents_Id_SEQ.nextval, 'DRIVE LICENSE'     , 'XXX 00003', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 11, 11 );
        INSERT INTO Documents VALUES (Documents_Id_SEQ.nextval, 'DRIVE LICENSE'     , 'XXX 00008', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 11, 11 );
        INSERT INTO Documents VALUES (Documents_Id_SEQ.nextval, 'DRIVE LICENSE'     , 'XXX 00001', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 11, 11 );
        INSERT INTO Documents VALUES (Documents_Id_SEQ.nextval, 'IDENTITY CARD'     , 'XXX 00004', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 11, 11 );
        INSERT INTO Documents VALUES (Documents_Id_SEQ.nextval, 'IDENTITY CARD'     , 'XXX 00001', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 11, 11 );
     
/*4*/
/* Creating a view for table 'Documents' for trigger 'Documents_TRG' */

CREATE OR REPLACE VIEW DocumentsView 
  as
    SELECT d.Document_Id, d.Document_Name, d.Document_Description , d.Record_Timestamp, d.Timestamp, d.Record_User_Id, d.User_Id     
    FROM Documents d;

/*5*/	
/* Creating a trigger which captures insert or update  instructions (to VIEW DocumentsView) and sets CURRENT_TIMESTAMP to 'Record_TimeStamp' and 'Timestamp' 
and also sets a current logged user to 'Record_User_id' and 'User_Id'.
The trigger works ONLY if someone is updating and inserting (into) 'DocumentsView' */ 

CREATE OR REPLACE TRIGGER Documents_TRG
       INSTEAD OF INSERT OR UPDATE ON DocumentsView
       BEGIN
/* Section for inserting NEW record(s)   */           
           IF INSERTING THEN
              INSERT INTO Documents 
                             (Document_Id     , Document_Name     , Document_Description     , Record_TimeStamp  ,  Timestamp        , Record_User_id, User_Id) 
                      VALUES (:new.Document_Id, :new.Document_Name, :new.Document_Description, CURRENT_TIMESTAMP ,  CURRENT_TIMESTAMP, ORA_LOGIN_USER, ORA_LOGIN_USER);   
           END IF;
 /* Section for updating existing record(s) */            
           IF UPDATING THEN
              UPDATE 
                Documents SET 
                 Document_id          = :new.Document_id  
                ,Document_Name        = :new.Document_Name 
                ,Document_Description = :new.Document_Description 
                ,Record_Timestamp     = :new.Record_Timestamp  
                ,Timestamp            = Current_Timestamp 
                ,Record_User_id       = :new.Record_User_id  
                ,User_id              = ORA_LOGIN_USER
 /* Condition that allows to change only updating rows */
                WHERE :old.Document_Id = Document_id; 
           END IF;
        END;
/

/*6*/
/* Creating PACKAGE (specification) for function 'Validate_Pesel' and procedure 'PRINT_DOCUMENTS'         */

CREATE OR REPLACE PACKAGE PeselPRNDocument IS
    FUNCTION VALIDATE_PESEL (PESEL NUMBER) RETURN VARCHAR2 ;
    PROCEDURE PRINT_DOCUMENTS;
END PESELPRNDOCUMENT;
/

/* Creating PACKAGE BODY (PESELPRNDOCUMENT) for function 'Validate_Pesel' and procedure 'PRINT_DOCUMENTS' */

CREATE or REPLACE PACKAGE BODY  PESELPRNDOCUMENT as

/* Begining of function 'Validate_Pesel'     */ 
	FUNCTION VALIDATE_PESEL (pesel NUMBER)
		RETURN VARCHAR2
		AS
		outresult VARCHAR2(5);
		errs      EXCEPTION;
		errl      EXCEPTION;
  
	BEGIN
 /* Exception for too short PESEL number   */
		IF LENGTH    (pesel)    < 11 
			THEN RAISE errs;
 /* Exception for too long PESEL number    */    
		ELSIF LENGTH (pesel)    > 11 
			THEN RAISE errl;
/* Validating cotrol digit for PESEL number */
		ELSE 

			SELECT CASE WHEN 
			SUBSTR( 
			(
			(SUBSTR(pesel, 1,  1) * 9) 
			+ (SUBSTR(pesel, 2,  1) * 7)
			+ (SUBSTR(pesel, 3,  1) * 3)
			+ (SUBSTR(pesel, 4,  1) * 1)
			+ (SUBSTR(pesel, 5,  1) * 9)
			+ (SUBSTR(pesel, 6,  1) * 7)
			+ (SUBSTR(pesel, 7,  1) * 3)
			+ (SUBSTR(pesel, 8,  1) * 1)
			+ (SUBSTR(pesel, 9,  1) * 9)
			+ (SUBSTR(pesel, 10, 1) * 7)
			) ,-1,1) =		  
            SUBSTR(PESEL,-1,1) THEN 'true' ELSE 'false' END
			INTO outresult
			FROM DUAL;
			RETURN outresult;
      END IF;
/* Exception section if PESEL number is too long or short then return error  */
    EXCEPTION
        WHEN errs THEN RETURN 'PESEL number is too SHORT'; 
        WHEN errl THEN RETURN 'PESEL number is too LONG'; 
	END VALIDATE_PESEL;
/* Begining procedure 'Print_Document' */
	PROCEDURE PRINT_DOCUMENTS IS
		CURSOR c is
		SELECT d.document_name, d.document_description
		FROM Documents d;
/* Declaring the same type of columns as in table - 'Documents'  */
		doc c%ROWTYPE;
		total_rows NUMBER;
    BEGIN
     /* Opening coursor 'c' and loading data from table 'Documents' to doc   */   
       OPEN c;
         LOOP
       
           FETCH c INTO doc;
           IF doc.document_description is not null 
               THEN dbms_output.put_line(doc.document_name);
           ELSE dbms_output.put_line('No Descripton');
           END IF;
/* When no rows to load into doc were found, end loop and close coursor 'c' */
           EXIT WHEN c%NOTFOUND;
           
         END LOOP;
         total_rows := c%ROWCOUNT;
         dbms_output.put_line('Returned:'||' '||total_rows||' '||'rows');
     CLOSE c;
     END;
END PESELPRNDOCUMENT;
/

/*7*/
/* Creating directory for XML file in oder to import */

CREATE OR REPLACE DIRECTORY XML_DIR AS 'C:\XML';

/*8*/
/* Creating sequence for table DocumentsXML */

CREATE SEQUENCE DocumentsXML_Id_SEQ;

/*9*/
/* Creating table */

CREATE TABLE DocumentsXML
    (
    Document_id NUMBER CONSTRAINT documentsxml_pk PRIMARY KEY,
    Document_Name VARCHAR2(255),
    Document_XML XMLTYPE
    )

/*10*/
/*Creating package which imports file from XML_DIR to table'Documents' and archives it in table DocumentsXML*/
CREATE OR REPLACE PACKAGE DOCIMP is  
PROCEDURE XMLIMP 
(FullFileName IN VARCHAR2 );
END DOCIMP;
/

CREATE OR REPLACE PACKAGE BODY DOCIMP is  
PROCEDURE XMLIMP 
(FullFileName IN VARCHAR2)
as
/* Condition for turning off case sensitive  */
UFullFileName VARCHAR2(255) := UPPER(FullFileName) ;
BEGIN

INSERT INTO DocumentsXML
    SELECT 
    DocumentsXML_Id_SEQ.nextval
    ,UFullFileName
    ,XMLType(BFILENAME
                    ('XML_DIR',UFullFileName)
                     ,NLS_CHARSET_ID('AL32UTF8')
             ) as abc
     FROM DUAL;
     DBMS_OUTPUT.PUT_LINE( 'File '||UFullFileName||' was loaded successfully' );
/* Inserting into the table documents using the view 'DocumentView'*/
INSERT INTO DocumentsView (DOCUMENT_ID, DOCUMENT_NAME, DOCUMENT_DESCRIPTION)


SELECT Documents_Id_SEQ.nextval, XMLA.DOCUMENT_NAME, XMLA.DOCUMENT_DESCRIPTION
     FROM DocumentsXML,
          XMLTABLE('/documents//document_header'
          PASSING DocumentsXML.DOCUMENT_XML
            COLUMNS 
           "DOCUMENT_NAME" 		  VARCHAR2(50) PATH '//Document_Name',
           "DOCUMENT_DESCRIPTION" VARCHAR2(50) PATH '//Document_Description'
           ) xmla
            
/* Condition not to duplicate documents in table 'Documents' which were imported earlier. */

    WHERE DocumentsXML.Document_Name = UFullFileName
/* Condition not to (multi)duplicate the same of documents name which were imported earlier (you can still import file of the same name as earlier)    */
    AND   Document_Id = (select max(document_id) from DocumentsXML);
	DBMS_OUTPUT.PUT_LINE('Number of inserted documents: ' || SQL%ROWCOUNT); 
    END;
END;
/



COMMIT;
SPOOL OFF