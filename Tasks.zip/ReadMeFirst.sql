
*       Author: Mariusz Kurzawi�ski     *
*         Date: 18.01.2018              *
*      Version: 1                       *
*  Description: Assessment              *


Scripts (in order):
1. TASK [1] Create Table    Documents
2. TASK [1] Create Sequence Documents_Id_SEQ for Documents
3. TASK [1]Populate Table  
4. TASK [1]Create View      DocumentsView for Documents
5. TASK [1]Create Trigger   Documents_TRG for Documents
6. TASK [2]Create Package   PeselPRNDocument (Validate_Pesel, Print Documents)
7. TASK [4]Create Directory for XML File
8. TASK [4]Create Sequence  DocumentsXML_Id_SEQ for table Documents
9. TASK [4]Create Table     DocumentsXML
10.TASK [4]Create Package   DOCIMP for import file to DocumentsXML

                        




1. Before You run script you have to declare directory for package which will insert XML into table 'Documents'.
   You can find it in line 170.
   
   For example: CREATE OR REPLACE DIRECTORY XML_DIR AS 'C:\XML';
   By default directory is XML_DIR and path 'C:\XML'   
  
2. Trigger works only when You updating or inserting into DocumentsView (view for table 'Documents')

3. For checking tasks:
/*

--TASK 1
SELECT *
FROM DocumentsView;

UPDATE DocumentsView set document_description = 'DRIVE LICENSE'
where document_id = 1;

INSERT INTO DocumentsView VALUES (Documents_Id_SEQ.nextval, 'PASSPORT'          , 'XXX 00001', null, null, null, null );


--TASK 2

--True
SELECT PESELPRNDOCUMENT.VALIDATE_PESEL(11111111116)
FROM dual;

--False
SELECT PESELPRNDOCUMENT.VALIDATE_PESEL(11111111115)
FROM dual;
--Exception
SELECT PESELPRNDOCUMENT.VALIDATE_PESEL(1111111111)
FROM dual;
SELECT PESELPRNDOCUMENT.VALIDATE_PESEL(111111111161)
FROM dual;

SET SERVEROUTPUT ON
exec PESELPRNDOCUMENT.PRINT_DOCUMENTS;

--TASK 4
exec DOCIMP.XMLIMP('SampleDocuments.xml');

select *
from DocumentsView;

*/
